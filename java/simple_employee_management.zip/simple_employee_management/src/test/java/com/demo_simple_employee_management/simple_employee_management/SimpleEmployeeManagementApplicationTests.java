package com.demo_simple_employee_management.simple_employee_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleEmployeeManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
