package com.demo_simple_employee_management.simple_employee_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleEmployeeManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleEmployeeManagementApplication.class, args);
	}

}
